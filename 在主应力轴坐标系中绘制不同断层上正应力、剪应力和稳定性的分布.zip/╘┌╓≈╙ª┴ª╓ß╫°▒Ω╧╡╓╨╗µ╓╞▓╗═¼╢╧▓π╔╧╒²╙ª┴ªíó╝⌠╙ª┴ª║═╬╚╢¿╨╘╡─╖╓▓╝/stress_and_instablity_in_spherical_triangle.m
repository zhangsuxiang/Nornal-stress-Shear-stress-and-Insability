function stress_and_instablity_in_spherical_triangle(R,friction,plot_variable,varargin)
% R: shape ratio, R=(sigma1-sigma2)/(sigma1-sigma3)
% plot_variable: specify plot variable
%    'ns': normal stress
%    'ss': shear stress
%    'i' : instability
% An optional input variable: 'isoline', Specifies the level of the contour
% for example: 
%    stress_and_instablity_in_spherical_triangle(0.5,0.6,'i','isoline',[0.6,0.7,0.8])

[x,y,ns,ss,instability]=NormalShearStress_and_instability(R,friction);

figure('color','w','position',[500,300,600,500])
hold on
axis equal
axis off
set(gca,'position',[0.15,0.2,0.6,0.6])
text(0.8,0.8,['R=',num2str(round(R,2))],'horizontalalignment','center','FontSize',14,'Fontname','TimesNewRoman')
h=colorbar('position',[0.82,0.25,0.025,0.4],'TickLength',0.02,'FontSize',12,'FontName','TimesNewRoman','LineWidth',0.8);

switch plot_variable
    case 'ns'
        pcolor(x,y,ns)
        caxis([-1,1])
        ylabel(h,'Normal stress','FontSize',12,'Fontname','TimesNewRoman')
        var=ns;

    case 'ss'
        pcolor(x,y,ss)
        caxis([0,1])
        ylabel(h,'Shear stress','FontSize',12,'Fontname','TimesNewRoman')
        var=ss;
        
    case 'i'
        pcolor(x,y,instability)
        caxis([0,1])
        ylabel(h,'Instability','FontSize',12,'Fontname','TimesNewRoman')
        var=instability;
        
end

isocline % �������������

% ���Ƶ�ֵ��
if isempty(varargin)
    if strcmp(plot_variable,'i')
        level_list=[0.7, 0.8, 0.9];
    else
        level_list=[ ];
    end
else
    level_list=varargin{2};
    if length(level_list)==1, level_list=level_list*[1, 1]; end
end
contour(x,y,var,level_list,'LineColor','k','ShowText','on','LineWidth',0.8)

shading interp
add_coordinate



end