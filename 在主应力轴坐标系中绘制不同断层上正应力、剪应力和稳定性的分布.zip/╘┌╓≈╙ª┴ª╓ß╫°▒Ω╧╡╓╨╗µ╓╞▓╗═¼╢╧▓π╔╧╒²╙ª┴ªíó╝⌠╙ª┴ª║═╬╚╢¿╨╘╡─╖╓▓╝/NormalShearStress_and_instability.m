function [h,v,ns,ss,instability]=NormalShearStress_and_instability(R,friction)

np=200;
n1_list=linspace(0,1,np);
n2_max=sqrt(1-n1_list.^2);
n1=repmat(n1_list,np,1);
n2=nan(np,np);
for i=1:np
    n2(:,i)=reshape(linspace(0,n2_max(i),np), np, 1);
end

n3=sqrt(1-n1.^2-n2.^2);

h=nan(np,np);
v=nan(np,np);
for i=1:np
    for j=1:np
        [h(i,j),v(i,j)]=kaverina(n1(i,j),n2(i,j),n3(i,j));
    end
end
h=real(h);
v=real(v);

% ���� Vavrycuk(2014) �ļ��㷽��
ns=n1.^2+(1-2*R)*n2.^2-n3.^2;
ss=sqrt( ( n1.^2+(1-2*R)^2*n2.^2+n3.^2 ) - ns.^2 );
ss=real(ss);
instability=( ss-friction*(ns-1) ) / ( friction+sqrt(1+friction^2) );


end