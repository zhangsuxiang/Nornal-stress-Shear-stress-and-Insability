function isocline

np=100;
inter=10;

color=[240,255,255]/255;

% ������ sigma1 ��ĵȼн���
d1=0:inter:90;
for i=1:length(d1)
    n1=cos(d1(i)*pi/180);
    n2_range=linspace(0,sqrt(1-n1^2),np);
    x=nan(1,np); y=nan(1,np);
    for j=1:np
        n2=n2_range(j);
        n3=sqrt(1-n1^2-n2^2);
        [x(j),y(j)]=kaverina(n1,n2,n3);
    end
    if d1(i)==90
        plot(real(x),real(y),'k','LineWidth',1.2)
    else
        plot(real(x),real(y),'-','color',color,'LineWidth',0.5)
    end
end

% ������ sigma2 ��ĵȼн���
d2=0:inter:90;
for i=1:length(d2)
    n2=cos(d2(i)*pi/180);
    n3_range=linspace(0,sqrt(1-n2^2),np);
    x=nan(1,np); y=nan(1,np);
    for j=1:np
        n3=n3_range(j);
        n1=sqrt(1-n2^2-n3^2);
        [x(j),y(j)]=kaverina(n1,n2,n3);
    end
    if d2(i)==90
        plot(real(x),real(y),'k','LineWidth',1.2)
    else
        plot(real(x),real(y),'-','color',color,'LineWidth',0.5)
    end
end

% ������ sigma3 ��ĵȼн���
d3=0:inter:90;
for i=1:length(d3)
    n3=cos(d3(i)*pi/180);
    n1_range=linspace(0,sqrt(1-n3^2),np);
    x=nan(1,np); y=nan(1,np);
    for j=1:np
        n1=n1_range(j);
        n2=sqrt(1-n1^2-n3^2);
        [x(j),y(j)]=kaverina(n1,n2,n3);
    end
    if d3(i)==90
        plot(real(x),real(y),'k','LineWidth',1.2)
    else
        plot(real(x),real(y),'-','color',color,'LineWidth',0.5)
    end
end


end