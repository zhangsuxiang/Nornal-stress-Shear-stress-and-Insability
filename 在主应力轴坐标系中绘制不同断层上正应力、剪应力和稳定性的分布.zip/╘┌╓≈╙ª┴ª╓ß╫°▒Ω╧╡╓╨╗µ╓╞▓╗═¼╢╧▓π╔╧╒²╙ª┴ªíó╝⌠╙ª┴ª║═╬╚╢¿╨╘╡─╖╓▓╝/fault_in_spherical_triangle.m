function [h,v]=fault_in_spherical_triangle(s1_str,s1_pl,s3_str,s3_pl,fault)
% fault=[strike,dip]
% 可输入多行数�?

s1_str=s1_str*pi/180; s1_pl=s1_pl*pi/180;
s3_str=s3_str*pi/180; s3_pl=s3_pl*pi/180;

fault=fault*pi/180;
f_num=size(fault,1);
strike=fault(:,1);
dip=fault(:,2);

s1_vector=[cos(s1_pl)*cos(s1_str); cos(s1_pl)*sin(s1_str); sin(s1_pl)];
s3_vector=[cos(s3_pl)*cos(s3_str); cos(s3_pl)*sin(s3_str); sin(s3_pl)];

normal=[-sin(strike).*sin(dip), cos(strike).*sin(dip), -cos(dip)];
L=abs(normal*s1_vector);
K=abs(normal*s3_vector);
M=sqrt(1-L.^2-K.^2);

h=nan(f_num,1);
v=nan(f_num,1);
for i=1:f_num
    [h(i),v(i)]=kaverina(L(i),M(i),K(i));
end


end