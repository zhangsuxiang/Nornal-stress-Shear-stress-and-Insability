function add_coordinate

inter=10;
n1=0;
d2=0:inter:90;
num=length(d2);

n2=cos( d2*pi/180 );
n3=sqrt(1-n1.^2-n2.^2);
x=nan(1,num);
y=nan(1,num);
for i=1:num
    [x(i),y(i)]=kaverina(n1,n2(i),n3(i));
end
text(x,y-0.07,[num2str(d2'),repmat('\circ',num,1)],'horizontalalignment','center','FontSize',12,'Fontname','TimesNewRoman')
% text(x(1)-0.08,y(1)-0.05,'\sigma_2','horizontalalignment','center','FontSize',18,'Fontname','TimesNewRoman')


n2=0;
d3=0:inter:90;
n3=cos( d3*pi/180 );
n1=sqrt(1-n2.^2-n3.^2);
x=nan(1,num);
y=nan(1,num);
for i=1:num
    [x(i),y(i)]=kaverina(n1(i),n2,n3(i));
end
text(x+0.09,y+0.04,[num2str(d3'),repmat('\circ',num,1)],'horizontalalignment','center','FontSize',12,'Fontname','TimesNewRoman')
% text(x(1)+0.12,y(1)-0.04,'\sigma_3','horizontalalignment','center','FontSize',18,'Fontname','TimesNewRoman')

n3=0;
d1=0:inter:90;
n1=cos( d1*pi/180 );
n2=sqrt(1-n1.^2-n3.^2);
x=nan(1,num);
y=nan(1,num);
for i=1:num
    [x(i),y(i)]=kaverina(n1(i),n2(i),n3);
end
text(x-0.075,y+0.04,[num2str(d1'),repmat('\circ',num,1)],'horizontalalignment','center','FontSize',12,'Fontname','TimesNewRoman')
% text(x(1),y(1)+0.12,'\sigma_1','horizontalalignment','center','FontSize',18,'Fontname','TimesNewRoman')

text(    0, -0.80, 'angle with \sigma_2','FontSize',12,'horizontalalignment','center','rotation',  0,'Fontname','TimesNewRoman');
text( 0.74,  0.39, 'angle with \sigma_3','FontSize',12,'horizontalalignment','center','rotation',-60,'Fontname','TimesNewRoman');
text(-0.74,  0.39, 'angle with \sigma_1','FontSize',12,'horizontalalignment','center','rotation', 60,'Fontname','TimesNewRoman');


end